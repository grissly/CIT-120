// Prints my name to the monitor
// Print My Name
// Programmer: Josh Guerra
// Last Modified: Sept. 21, 2015

#include <iostream>
using namespace std;

void main() {
	cout << "Josh Guerra" << endl << endl;

	system("pause");
}